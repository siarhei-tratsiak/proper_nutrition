import Dexie from 'dexie'
import { products0 } from '@/data/products0'
import { products1 } from '@/data/products1'
import { products2 } from '@/data/products2'
import { products3 } from '@/data/products3'
import { products4 } from '@/data/products4'
import { products5 } from '@/data/products5'
import { products6 } from '@/data/products6'
import { products7 } from '@/data/products7'
import { products8 } from '@/data/products8'
import { DBName, productsColumnsNames } from '@/data/DBSettings'

async function initDatabase () {
  const db = await createDB()
  const count = await db.products.count()
  const products = [...products0, ...products1, ...products2, ...products3, ...products4, ...products5, ...products6, ...products7, ...products8]
  if (count < products.length) { fillDB(db, products) }
  return db
}

async function createDB () {
  const db = new Dexie(DBName)
  const columnNames = productsColumnsNames.join(', ')
  db.version(1).stores({
    products: columnNames
  })
  return db
}

async function fillDB (db, products) {
  const valuesList = await prepareData(products)
  db.transaction('rw', db.products, () => {
    valuesList.forEach(row => {
      db.products.put(row)
    })
  }).catch(function (e) {
    console.log(e)
  })
}

function prepareData (products) {
  const keys = productsColumnsNames
  let valuesList = products
  valuesList = valuesList.map(values => {
    let obj = {}
    keys.forEach(function (key, value) {
      obj[key] = values[value]
    })
    return obj
  })
  return valuesList
}

export {
  initDatabase
}
