import { deepStrictEqual } from 'assert'
import { multiply, add, transpose } from 'mathjs'

function mapVector (namedVector) {
  const varNames = Object.keys(namedVector).sort()
  const indicesToNames = {}
  const namesToIndices = {}
  const vectorValues = []
  varNames.forEach((coefficientName, index) => {
    indicesToNames[`${index}`] = coefficientName
    namesToIndices[coefficientName] = index
    vectorValues.push(namedVector[coefficientName])
  })
  return {
    varNames,
    indicesToNames,
    namesToIndices,
    vectorValues
  }
}

function completeCoefficientVector ({
  vector,
  allNames
}) {
  const nextVector = {}
  allNames.forEach((curName) => {
    const vectorValue = vector[curName]
    const curValue = vectorValue || 0
    nextVector[curName] = curValue
  })
  return nextVector
}

function assertCoefficientParallelism ({
  objective,
  constraints
}) {
  const objectiveVector = mapVector(objective).varNames
  const constraintVectors = constraints.map((constraint) => (
    mapVector(constraint.namedVector).varNames
  ))
  constraintVectors.forEach((constraintVector) => {
    deepStrictEqual(constraintVector, objectiveVector)
  })
}

function generateTableauRow ({
  vectorValues,
  constant = 0,
  rowNo = 0,
  numRows = 1
}) {
  const firstPart = vectorValues
  const firstZeroes = new Array(rowNo).fill(0)
  const secondZeroes = new Array(numRows - rowNo - 1).fill(0)
  const secondPart = [
    ...firstZeroes,
    1,
    ...secondZeroes
  ]
  return [
    ...firstPart,
    ...secondPart,
    constant
  ]
}

function constraintToPreRow ({
  namedVector,
  constraint,
  constant = 0
}) {
  const { vectorValues } = mapVector(namedVector)
  if (constraint === '<=') {
    return {
      vectorValues,
      constant
    }
  } else if (constraint === '>=') {
    return {
      vectorValues: multiply(vectorValues, -1),
      constant: constant * -1
    }
  }
  throw new Error('Not in standardized form')
}

function getLastRow (tableau) {
  return tableau[tableau.length - 1]
}

function getColumn ({
  tableau,
  columnNo
}) {
  return tableau.map((row) => row[columnNo])
}

function getLastColumn (tableau) {
  const columnNo = tableau[0].length - 1
  return getColumn({
    tableau,
    columnNo
  })
}

function getPivotColumnIndex (tableau) {
  const lastRow = getLastRow(tableau)
  const pivotColumnPair = lastRow.reduce((accMin, curEntry, curIndex) => {
    if (accMin.value <= curEntry) return accMin
    return { value: curEntry, index: curIndex }
  }, { value: 0, index: -1 })
  return pivotColumnPair.index
}

function getPivotRowIndex (tableau) {
  const lastColumn = getLastColumn(tableau)
  const lastConstraintColumn = lastColumn.slice(0, lastColumn.length - 1)
  const pivotColumnIndex = getPivotColumnIndex(tableau)
  const pivotColumn = getColumn({
    tableau,
    columnNo: pivotColumnIndex
  })
  const pivotConstraintColumn = pivotColumn.slice(0, pivotColumn.length - 1)
  const dividedLastColumn = lastConstraintColumn.map(
    (entry, index) => entry / pivotConstraintColumn[index]
  )
  const pivotRowPair = dividedLastColumn.reduce((accMin, curEntry, curIndex) => {
    // can the acc min be negative?
    // if (pivotConstraintColumn[curIndex] < 0) return accMin
    if (accMin.value <= curEntry) return accMin
    if (curEntry < 0) return accMin
    return { value: curEntry, index: curIndex }
  }, { value: Infinity, index: -1 })
  if (pivotRowPair.index === -1) throw new Error('the task has no solutions')
  return pivotRowPair.index
}

function adjustNonPivotRow ({
  nonPivotRow,
  adjustedPivotRow,
  pivotCoords
}) {
  const {
    colNo
  } = pivotCoords
  const pivotRowMultiplier = nonPivotRow[colNo] * -1
  const multipliedPivotRow = multiply(adjustedPivotRow, pivotRowMultiplier)
  const adjustedInputRow = add(nonPivotRow, multipliedPivotRow)
  adjustedInputRow[colNo] = 0
  return adjustedInputRow
}

function adjustPivotRow ({
  pivotRow,
  pivotCoords
}) {
  const {
    colNo
  } = pivotCoords
  const pivotEntry = pivotRow[colNo]
  const adjustedPivotRow = pivotRow.map((curEntry) => curEntry / pivotEntry)
  adjustedPivotRow[colNo] = 1
  return adjustedPivotRow
}

function getPivotCoords (tableau) {
  return {
    rowNo: getPivotRowIndex(tableau),
    colNo: getPivotColumnIndex(tableau)
  }
}

function applyPivoting (tableau, indicesToNames, rowIndicesToNames) {
  const pivotCoords = getPivotCoords(tableau)
  const {
    rowNo,
    colNo
  } = pivotCoords
  const pivotRow = tableau[rowNo]
  const adjustedPivotRow = adjustPivotRow({
    pivotRow,
    pivotCoords
  })
  const nextTableau = tableau.map((curRow, curIndex) => {
    if (curIndex === rowNo) return adjustedPivotRow
    return adjustNonPivotRow({
      nonPivotRow: curRow,
      adjustedPivotRow,
      pivotCoords
    })
  })
  rowIndicesToNames[rowNo] = indicesToNames[colNo]
  return { nextTableau, rowIndicesToNames }
}

function isAllNonNegative (vector) {
  return vector.reduce((acc, curItem) => acc && (curItem >= 0), true)
}

function isActive (vector) {
  const numNonZeroes = vector.reduce((acc, curItem) => {
    if (curItem === 0) return acc
    return acc + 1
  })
  return numNonZeroes === 1
}

function getActiveVarCoefficient (column) {
  return column.reduce((acc, curEntry, index) => {
    if (curEntry === 0) return acc
    return { index, value: curEntry }
  }, { index: -1, value: undefined })
}

function extractNamedSolution ({
  tableau,
  indicesToNames,
  rowIndicesToNames,
  allNames
}) {
  const lastColumn = getLastColumn(tableau)
  const allColumns = transpose(tableau)
  const activeColumnIndices = allColumns.slice(0, -1)
    .map((curColumn, curIndex) => ({
      isActiveColumn: isActive(curColumn),
      index: curIndex
    }))
    .filter(({ isActiveColumn }) => isActiveColumn)
    .map(({ index }) => index)
  const activeVarCoefficients = activeColumnIndices
    .map((curActiveIndex) => getActiveVarCoefficient(allColumns[curActiveIndex]))
  const activeVarIndicesAndValues = activeVarCoefficients.map((activeVarCoefficient, curIndex) => {
    const curActiveIndex = activeColumnIndices[curIndex]
    const curActiveValue = lastColumn[activeVarCoefficient.index] / activeVarCoefficient.value
    return {
      index: curActiveIndex,
      value: curActiveValue
    }
  })
  const vector = {}
  activeVarIndicesAndValues.forEach(({ index, value }) => {
    const indexString = `${index}`
    if (!indicesToNames[indexString]) return
    const coefficientName = indicesToNames[indexString]
    vector[coefficientName] = value
  })
  const optimum = activeVarIndicesAndValues[activeVarIndicesAndValues.length - 1].value
  /* const coefficients = completeCoefficientVector({
    vector,
    allNames
  }) */
  const vector2 = {}
  for (let [key, value] of Object.entries(rowIndicesToNames)) {
    if (value) {
      vector2[value] = lastColumn[key]
    }
  }
  // console.log(JSON.stringify(vector) === JSON.stringify(vector2))
  return {
    coefficients: vector2,
    optimum
  }
}

export {
  mapVector,
  assertCoefficientParallelism,
  generateTableauRow,
  constraintToPreRow,
  getPivotColumnIndex,
  getPivotRowIndex,
  getPivotCoords,
  getLastRow,
  applyPivoting,
  adjustPivotRow,
  adjustNonPivotRow,
  isAllNonNegative,
  isActive,
  extractNamedSolution,
  completeCoefficientVector
}
