import { multiply } from 'mathjs'
import { simplex } from './algorithms/simplex'

import {
  mapVector,
  assertCoefficientParallelism,
  generateTableauRow,
  constraintToPreRow,
  extractNamedSolution
} from './simplex-helpers'

export default class SimpleSimplex {
  constructor ({
    optimizationType,
    objective,
    constraints
  }) {
    assertCoefficientParallelism({
      objective,
      constraints
    })
    this.objective = objective
    this.constraints = constraints
    this.optimizationType = optimizationType
    this.numRows = constraints.length + 1
    const {
      varNames,
      indicesToNames,
      namesToIndices,
      vectorValues
    } = mapVector(objective)
    this.varNames = varNames
    this.indicesToNames = indicesToNames
    this.namesToIndices = namesToIndices
    this.objectiveVectorValues = vectorValues
    this.tableau = this.generateTableau()
  }

  generateTableau () {
    if (this.optimizationType !== 'max') throw new Error('not a maximization problem')
    const constraintPreRows = this.constraints.map(constraintToPreRow)
    const constraintTableauRows = constraintPreRows.map((preRow, index) => generateTableauRow({
      ...preRow,
      rowNo: index,
      numRows: this.numRows
    }))
    const objectiveTableauRow = generateTableauRow({
      vectorValues: multiply(this.objectiveVectorValues, -1),
      rowNo: this.numRows - 1,
      numRows: this.numRows
    })
    const tableau = [
      ...constraintTableauRows,
      objectiveTableauRow
    ]
    return tableau
  }

  solve ({
    methodName
  }) {
    if (methodName !== 'simplex') throw new Error('unrecognized algorithm name')
    const details = simplex({
      tableau: this.tableau,
      indicesToNames: this.indicesToNames
    })
    if (!details.isOptimal) throw new Error('solution is not optimal!')
    const solution = extractNamedSolution({
      tableau: details.finalTableau,
      indicesToNames: this.indicesToNames,
      rowIndicesToNames: details.rowIndicesToNames,
      allNames: this.varNames
    })
    return {
      details,
      solution
    }
  }
};
