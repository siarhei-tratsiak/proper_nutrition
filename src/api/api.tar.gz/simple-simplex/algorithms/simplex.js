import {
  getLastRow,
  applyPivoting,
  isAllNonNegative
} from '../simplex-helpers'

function isTableauOptimal (tableau) {
  const lastRow = getLastRow(tableau)
  return isAllNonNegative(lastRow)
}

function simplex ({
  tableau,
  indicesToNames,
  maxIterations = 50
}) {
  let curTableau = tableau
  let curIteration = 0
  const tableaus = []
  let rowIndicesToNames = {}
  while (!isTableauOptimal(curTableau) && curIteration < maxIterations) {
    tableaus.push(curTableau)
    let appledPivoting = applyPivoting(curTableau, indicesToNames, rowIndicesToNames)
    curTableau = appledPivoting.nextTableau
    rowIndicesToNames = appledPivoting.rowIndicesToNames
    curIteration += 1
  }
  // console.log(curIteration)
  return {
    finalTableau: curTableau,
    tableaus,
    rowIndicesToNames,
    isOptimal: isTableauOptimal(curTableau)
  }
};

export {
  simplex
}
