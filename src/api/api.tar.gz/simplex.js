// https://function-x.ru/simplex_method_example_algorithm.html
var time = undefined

function getTime (functionName) {
  console.log(functionName, ' = ', performance.now() - time)
}

function simplex (conditions) {
  time = performance.now()
  let simplexTable = buildSimplexTable(conditions)
  const rows = simplexTable.length
  const columns = simplexTable[0].length
  // getTime('buildSimplexTable')
  // console.log(simplexTable)
  let freeUnknownsList = createFreeUnknownsList(columns)
  // getTime('createFreeUnknownsList')
  // console.log('freeUnknownsList: ', freeUnknownsList[0])
  let baseUnknownsList = createBaseUnknownsList(rows, columns)
  // getTime('baseUnknownsList')
  // console.log('baseUnknownsList: ', baseUnknownsList)

  let countOfIterations = 0
  const iterationsLimit = 100
  let updateIsPossible = true
  while (!isOptimal(simplexTable, rows, conditions.optimizationType) &&
          countOfIterations < iterationsLimit &&
          updateIsPossible) {
    let updateResult = updateSimplexTable(simplexTable, freeUnknownsList, baseUnknownsList, rows, columns)
    updateIsPossible = updateResult.updateIsPossible
    simplexTable = updateResult.simplexTable
    countOfIterations++
  }
  console.log('countOfIterations: ', countOfIterations)
  const result = getResult(simplexTable, baseUnknownsList)
  // console.log('result: ', result)
  getTime('result')
  return result
}

function buildSimplexTable (conditions) {
  let simplexTable = []

  conditions.constraints.forEach(constraint => addRowToTable(simplexTable, constraint))
  addIndexRow(simplexTable, conditions)

  return simplexTable
}

function addRowToTable (simplexTable, constraint) {
  const minus = constraint.constraint === '<=' ? 1 : -1
  const freeMember = minus * constraint.constant
  const freeUnknowns = minus === -1 ? Object.values(constraint.namedVector).map(freeUnknown => minus * freeUnknown) : Object.values(constraint.namedVector)
  const auxilaryFactor = undefined

  simplexTable.push([freeMember, ...freeUnknowns, auxilaryFactor])
  // getTime('addRowToTable')
}

function addIndexRow (simplexTable, conditions) {
  const constraint = {
    namedVector: conditions.objective,
    constraint: conditions.optimizationType === 'max' ? '>=' : '<=',
    constant: 0
  }
  addRowToTable(simplexTable, constraint)
}

function createFreeUnknownsList (columns) {
  let freeUnknownsList = [[]]
  createFirst(freeUnknownsList, columns)
  return freeUnknownsList
}

function createFirst (freeUnknownsList, columns) {
  for (let i = 0; i < columns - 1; i++) {
    freeUnknownsList[0].push(i)
  }
}

function createBaseUnknownsList (rows, columns) {
  const firstBaseUnknown = columns - 2
  const lastBaseUnknown = firstBaseUnknown + rows - 2
  let baseUnknownsList = []
  for (let i = 0; i <= lastBaseUnknown - firstBaseUnknown; i++) {
    baseUnknownsList.push(i + firstBaseUnknown)
  }
  return baseUnknownsList
}

function isOptimal (simplexTable, rows, optimizationType) {
  const indexRow = simplexTable[rows - 1].slice(1, -1)
  // // console.log('indexRow: ', indexRow, optimizationType)
  const isOptimal = optimizationType === 'max' ? Math.min(...indexRow) >= 0 : Math.max(...indexRow) <= 0
  // getTime('isOptimal')
  return isOptimal
}

function updateSimplexTable (simplexTable, freeUnknownsList, baseUnknownsList, rows, columns) {
  let rejectColumns = []
  let leadColumn, leadRow, leadElement, freeUnknowns, freeUnknown
  do {
    leadColumn = findLeadColumn(simplexTable, rejectColumns, rows)
    // console.log('leadColumn: ', leadColumn)
    leadRow = findLeadRow(simplexTable, leadColumn)
    // console.log('leadRow: ', leadRow)
    leadElement = simplexTable[leadRow][leadColumn]
    // console.log('leadElement: ', leadElement)
    if (leadElement !== 0) {
      freeUnknowns = Object.assign([], freeUnknownsList[freeUnknownsList.length - 1])
      // // console.log('freeUnknowns: ', freeUnknowns)
      freeUnknown = freeUnknowns[leadColumn - 1]
      freeUnknowns[leadColumn - 1] = baseUnknownsList[leadRow]
      // // console.log('freeUnknowns: ', freeUnknowns)
    }
    if (rejectColumns.length === columns - 2) {
      // console.log('update is impossible')
      return { updateIsPossible: false, simplexTable: simplexTable }
    }
    rejectColumns.push(leadColumn)
  } while (leadElement === 0 || inList(freeUnknownsList, freeUnknowns))
  freeUnknownsList.push(freeUnknowns)
  // console.log('freeUnknownsList: ', freeUnknownsList[freeUnknownsList.length - 1])
  baseUnknownsList.splice(leadRow, 1)
  // console.log('baseUnknownsList: ', baseUnknownsList)
  baseUnknownsList.unshift(freeUnknown)
  // console.log('baseUnknownsList: ', baseUnknownsList)
  simplexTable = rewriteSimplexTable(simplexTable, leadElement, leadRow, leadColumn, rows, columns)
  // console.log(simplexTable)
  return { updateIsPossible: true, simplexTable: simplexTable }
}

function findLeadColumn (simplexTable, rejectColumns, rows) {
  let indexRowfreeUnknowns = simplexTable[rows - 1].slice(1, -1)
  rejectColumns.forEach(function (rejectColumn) {
    indexRowfreeUnknowns[rejectColumn - 1] = undefined
  })
  const absIndexRowfreeUnknowns = indexRowfreeUnknowns.map(member =>
    member === undefined ? -1 : Math.abs(member))
  // // console.log('absIndexRowfreeUnknowns: ', absIndexRowfreeUnknowns)
  const leadColumn = absIndexRowfreeUnknowns.indexOf(Math.max(...absIndexRowfreeUnknowns)) + 1

  return leadColumn
}

function findLeadRow (simplexTable, leadColumn) {
  // // console.log('minRow: ', simplexTable.map(row => row[0]))
  // // console.log('minRow: ', simplexTable.map(row => row[leadColumn]))
  const minRow = simplexTable.map(row => {
    const freeMember = row[0]
    const leadColumnElement = row[leadColumn]

    if (leadColumnElement === 0 || (leadColumnElement < 0 && freeMember > 0)) {
      return Infinity
    }

    return freeMember / leadColumnElement
  }).slice(0, -1)
  // // console.log('minRow: ', minRow)
  return minRow.indexOf(Math.min(...minRow))
}

function inList (freeUnknownsList, freeUnknowns) {
  let inList = false
  let counter = 0
  let freeUnknowns1
  let freeUnknowns2 = Object.assign([], freeUnknowns)
  freeUnknowns2.sort()
  // // console.log('freeUnknowns2: ', freeUnknowns2)

  while (!inList && counter < freeUnknownsList.length) {
    freeUnknowns1 = Object.assign([], freeUnknownsList[counter])
    freeUnknowns1.sort()
    // // console.log(freeUnknownsList)
    // // console.log('freeUnknowns1: ', freeUnknowns1)
    inList = freeUnknowns1.every((value, index) => value === freeUnknowns2[index])
    counter++
  }

  return inList
}

function rewriteSimplexTable (simplexTable, leadElement, leadRow, leadColumn, rows, columns) {
  let newSimplexTable = []
  newSimplexTable[0] = simplexTable[leadRow].map(item => item / leadElement)
  newSimplexTable[0][leadColumn] = 1 / leadElement
  newSimplexTable[0][columns - 1] = undefined
  let auxilaryFactors = simplexTable.map(row => -row[leadColumn])
  auxilaryFactors.splice(leadRow, 1)
  /* const firstRow = [...simplexTable[0]]
  const leadRowRow = [...simplexTable[leadRow]]
  simplexTable[0] = leadRowRow
  simplexTable[leadRow] = firstRow */

  for (let i = 1; i < rows; i++) {
    const j = i <= leadRow ? 1 : 0
    const auxilaryFactor = auxilaryFactors[i - 1]
    newSimplexTable[i] = newSimplexTable[0].map((item, index) => item * auxilaryFactor + simplexTable[i - j][index])
    newSimplexTable[i][columns - 1] = auxilaryFactor
    newSimplexTable[i][leadColumn] -= simplexTable[i - j][leadColumn]
  }

  return newSimplexTable
}

function getResult (simplexTable, baseUnknownsList) {
  let result = []
  for (let i = 0; i < simplexTable[0].length - 2; i++) {
    const freeUnknownIndex = baseUnknownsList.indexOf(i)
    if (freeUnknownIndex !== -1) {
      result.push([i, simplexTable[freeUnknownIndex][0]])
    }
  }
  return result
}

/* const conditions = {
  objective: {
    a: 70,
    b: 210,
    c: 140
  },
  constraints: [
    {
      namedVector: { a: 1, b: 1, c: 1 },
      constraint: '<=',
      constant: 100
    },
    {
      namedVector: { a: 5, b: 4, c: 4 },
      constraint: '<=',
      constant: 480
    },
    {
      namedVector: { a: 40, b: 20, c: 30 },
      constraint: '<=',
      constant: 3200
    }
  ],
  optimizationType: 'max'
} */
export { simplex }
